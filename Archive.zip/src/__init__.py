"""
Source directory for A2A MCP package
""" 
